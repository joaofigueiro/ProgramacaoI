import java.util.Scanner; 

class Acampamento{
    private String nome;
    private int idade;
    private char equipe;

    Acampamento(String nome, int idade){
        this.setNome(nome);
        this.setIdade(idade);
    }

    void setNome(String nome){
        this.nome = nome;
    }

    String getNome(){
        return nome; 
    }

    void setIdade(int idade){
        this.idade = idade;
    }

    int getIdade(){
        return idade;
    }

    void definirEquipe(){
        if(idade >= 6 && idade <= 10){
            this.setEquipe('A');
        } else if (idade >= 11 && idade <= 20){
            this.setEquipe('B');
        } else if (idade >= 21){
            this.setEquipe('C');
        }
    }

    void setEquipe(char equipe){
        this.equipe = equipe;
    }

    char getEquipe(){
        return equipe; 
    }

    @Override
    public String toString(){
        return nome + ' ' + idade + ' ' + equipe;
    }
}

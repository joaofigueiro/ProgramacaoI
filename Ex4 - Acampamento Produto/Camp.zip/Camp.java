import java.util.Scanner; 

public class Camp {
    public static void main(String[] args){
        String nome;
        int idade;

        Acampamento[] integrantes = new Acampamento[10];

        Scanner nomePessoa = new Scanner(System.in);
        Scanner idadePessoa = new Scanner(System.in);
        for(int i = 0; i < 10; i++){
            System.out.print("Digite seu nome completo: ");
            nome = nomePessoa.nextLine();

            System.out.print("Digite sua idade: ");
            idade = idadePessoa.nextInt();

            integrantes[i] = new Acampamento(nome, idade);
            integrantes[i].definirEquipe();
        }

        idadePessoa.close();
        nomePessoa.close();

        for(int i = 0; i < 10; i++){
            System.out.println(integrantes[i].toString());
        }
    }
}

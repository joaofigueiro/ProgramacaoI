import java.util.Scanner; 
import java.util.ArrayList;

public class ProdutoTeste {
    public void menu() {
        System.out.println("1 – Cadastrar Produto");
        System.out.println("2 – Consultar estoque");
        System.out.println("3 – Remover unidades");
        System.out.println("4 – Adicionar unidades");
        System.out.println("9 – Sair");
    }

    public void cadastrarProduto(ArrayList<Produto> produtos) {
        String nome; 
        float valor; 
        int quantidade;   

        Scanner scanner = new Scanner(System.in);
        Produto produto = new Produto();

        System.out.print("Digite o nome do produto: ");
        nome = scanner.nextLine();
        produto.setNome(nome);

        System.out.print("Digite o valor do produto: ");
        valor = scanner.nextFloat();
        produto.setValor(valor);

        System.out.print("Digite a quantidade do produto: ");
        quantidade = scanner.nextInt();
        produto.setQuantidade(quantidade);

        produtos.add(produto);
    }

    public void consultarEstoqueProduto(ArrayList<Produto> produtos) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o index do produto: ");
        int index = scanner.nextInt();

        System.out.println(produtos.get(index));
    }

    public void removerProduto(ArrayList<Produto> produtos) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o index do produto: ");
        int index = scanner.nextInt();

        System.out.print("Quantidade a ser removida: ");
        int quantidade = scanner.nextInt();

        Produto produto = produtos.get(index);

        if(produto.removerUnidades(quantidade)) {
            System.out.println("Quantidade removida com sucesso!");
        } else {
            System.out.println("Quantidade insuficiente para remoção!");
        }
    }

    public void adicionarUnidades(ArrayList<Produto> produtos) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o index do produto: ");
        int index = scanner.nextInt();

        System.out.print("Quantidade a ser adicionada: ");
        int quantidade = scanner.nextInt();

        Produto produto = produtos.get(index);

        produto.adicionarQuantidade(quantidade);

        System.out.println("Quantidade adicionada com sucesso!");
    }

    public static void main(String[] args){
        Scanner controlScanner = new Scanner(System.in);
        ArrayList<Produto> produtos = new ArrayList<Produto>();
        ProdutoTeste obj = new ProdutoTeste();

        int control = 0;

        while(control != 9) {
            obj.menu();
            control = controlScanner.nextInt();

            if(control == 1) {
                obj.cadastrarProduto(produtos);
            }
            else if(control == 2) {
                obj.consultarEstoqueProduto(produtos);
            }
            else if(control == 3) {
                obj.removerProduto(produtos);
            }
            else if(control == 4) {
                obj.adicionarUnidades(produtos);
            }
        }
    }
}

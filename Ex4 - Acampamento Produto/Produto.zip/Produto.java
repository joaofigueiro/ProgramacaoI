public class Produto {
    private String nome; 
    private float valor; 
    private int quantidade;   

    public void setNome(String nomeProd){
        this.nome = nomeProd; 
    }
    
    public String getNome(){
        return nome; 
    }

    public void setValor(float valorProd){
        this.valor = valorProd; 
    }

    public float getValor(){
        return valor; 
    }

    public void setQuantidade(int quantidade){
        this.quantidade = quantidade; 
    }

    public boolean verificarDisponibilidade(int qtdeProd){
        return this.quantidade >= qtdeProd; 
    }

    public void adicionarQuantidade(int qtdeAdic){
        this.quantidade += qtdeAdic; 
    }

    public boolean removerUnidades(int qtdeRem){
        if(this.verificarDisponibilidade(qtdeRem)) {
            this.quantidade -= qtdeRem; 
            return true;
        }
        return false;
    }

    @Override
    public String toString(){
        return nome + ' ' + valor + ' ' + quantidade;
    }
}
